@extends('app')

@section('title', 'Registration Success')
    
@section('content')
<div class="subPages">
	<h2>Patient Registration</h2>
		
	
		
		
            <div class="clearfix patientinfo">
					<div class="signupSeccMsg">
						Thank you for your registration information.  Please check your email inbox for a link we sent you to verify your email address.
					</div>
		    </div>	
		    </div>	
		
	    
	    
	    
	    	
@endsection