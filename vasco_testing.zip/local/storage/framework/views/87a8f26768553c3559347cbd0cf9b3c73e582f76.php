<?php $__env->startSection('title', 'Edit profile'); ?>
    
<?php $__env->startSection('content'); ?>
    
	<div class="row">
		<div class="col-lg-12">
			<div class="col-lg-2">
				<ul>
					<li><?php echo e(Html::link('dashboard', 'Dashboard',array('class' => Helpers::isActiveRoute('dashboard')))); ?></li>
					<li><?php echo e(Html::link(route('edit_profile'), 'Edit Profile',array('class' => Helpers::isActiveRoute('edit_profile')))); ?></li>
					<!--<li><?php echo e(Html::link(route('edit_billing'), 'Edit Billing',array('class' => Helpers::isActiveRoute('edit_billing')))); ?></li>-->
					<li><?php echo e(Html::link(route('change_password'), 'Password Change',array('class' => Helpers::isActiveRoute('change_password')))); ?></li>
					<li><?php echo e(Html::link(route('logout'), 'Logout')); ?></li>	
				</ul>
			</div>
			<div class="col-lg-10">
				<h2>Edit Billing</h2>
					<?php if(count($errors) > 0): ?> 
					    <div class="alert alert-danger">
					    <ul>
						    <?php foreach($errors->all() as $error): ?>
							    <li><?php echo e($error); ?></li>
						    <?php endforeach; ?>
					    </ul>
					    </div>
					<?php endif; ?>
					<?php if(Session::has('succ_msg')): ?>
						<div class="alert alert-success">
							<ul>
								<li><?php echo e(Session::get('succ_msg')); ?></li>
							</ul>
						</div>
					<?php endif; ?>
				    <?php echo Form::open(array('route'=>'update_billing','id' => 'editProfile','novalidate'=>'novalidate')); ?>

				    <div class="form-group">
				       <label for="first_name">Credit Card Number:</label>
				    <?php echo Form::text('credit_card','xxxxxxxxxxxx'.$billing->credit_card,array('placeholder'=>'Credit Card Number','class'=>'form-control')); ?>

				    </div>
				    <div class="form-group">
				    <label for="last_name">Expiry Date:</label>
				    <?php echo Form::selectMonth('exp_month',date('m',strtotime($billing->exp_date))); ?>

				      <?php echo Form::selectYear('exp_year',  date('Y') + 20, date('Y'),$billing->exp_date?date('Y',strtotime($billing->exp_date)):date('Y')); ?>

				    </div>
				    <div class="form-group">
				    <label for="last_name">CVV:</label>
				    <?php echo Form::text('cvv',$billing->	cvv_code,array('placeholder'=>'CVV','class'=>'form-control')); ?>

				    </div>
				    <div class="form-group">
				      <label for="email">Home address:</label>
				      <?php echo Form::textarea('home_address',$billing->home_address,array('class'=>'form-control homeAddress')); ?>

				    </div>
					
					<div class="form-group">
				      <label for="email">Billing address:</label>
					  <label><?php echo Form::checkbox('copyAddress','yes','',array('class'=>'copyAddress')); ?> Same as home address</label>
				      <?php echo Form::textarea('billing_address',$billing->billing_address,array('class'=>'form-control billingAddress')); ?>

				    </div>
				    <?php echo Form::submit('Submit',array('class'=>'btn btn-default')); ?>

				    <?php echo Form::close(); ?>

			</div>
		</div>
	</div>
    
	<script>
		
		$(function(){
			$('.homeAddress').keydown(function(){
				if($('.copyAddress').is(':checked')){
					$('.billingAddress').val($('.homeAddress').val());
				}
			});
			$('.copyAddress').on('click',function(){
		
				if ($(this).is(':checked')) {
					$('.billingAddress').val($('.homeAddress').val());
				}else{
					$('.billingAddress').val('');
				}
			});
			
		})
		
	</script>
		
	
	
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>