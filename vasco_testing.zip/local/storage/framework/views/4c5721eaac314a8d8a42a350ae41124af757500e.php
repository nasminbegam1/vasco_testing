<!DOCTYPE html>
<html>
<body>
    <p>Welcome to the VascoRX Patient Portal.  You may now <a href="<?php echo e(URL::route('user_login')); ?>">log in</a> to complete your profile.  Please contact us for any questions or concerns.</p>
        <p>
        SIncerely,
        <br>
        The VascoRX team
    </p>
</body>
</html>

