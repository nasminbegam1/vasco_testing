<?php $__env->startSection('title', 'Dashboard'); ?>
    
<?php $__env->startSection('content'); ?>
	
	<div class="row welcomeTop">
		<div class="col-sm-3">
		<span class="welcomeUserName">Welcome <strong><?php echo e(ucwords($details->first_name) . ' '. ucwords($details->last_name)); ?></strong>!</span>
		</div>
		<div class="col-sm-9">
			<div class="rightDrop">
			<span class="logout"><?php echo e(Html::link(route('logout'), 'Logout')); ?></span>
			<div class="dropdown">
			<span class="dropdownTitle">Dashboard</span>
			<ul>
					<li><?php echo e(Html::link('dashboard', 'Dashboard',array('class' => Helpers::isActiveRoute('dashboard')))); ?></li>
					<li><?php echo e(Html::link(route('edit_profile'), 'Edit Profile and Billing',array('class' => Helpers::isActiveRoute('edit_profile')))); ?></li>
					<!--<li><?php echo e(Html::link(route('edit_billing'), 'Edit Billing',array('class' => Helpers::isActiveRoute('edit_billing')))); ?></li>-->
					<li><?php echo e(Html::link(route('change_password'), 'Change Password',array('class' => Helpers::isActiveRoute('change_password')))); ?></li>
				</ul>
				</div>
				</div>
		</div>
		</div>
		<div class="row welcomeText">
		<div class="col-sm-12">
		<p>
		Thank you for visiting the VascoRX Patient Portal, where you can update your profile and billing information, and let us know about your current medications, allergies and medical conditions, so that we can better serve you.</p>
		</div>
		</div>
		<div class="formFiled">
	<h4>Medications</h4>
	<table border="0" width="100%" cellpadding="0" cellspacing="0">
		<thead>
			<tr>
				<th></th>
				<th>Medication (Prescription OTC or Herbal)</th>
				<th>Dosage</th>
				<th>How Often (Frequency)</th>
			</tr>
		</thead>
		<tbody class="medicationAdd">
		<?php if($medications->count() > 0): ?>
			<?php foreach($medications as $med): ?>
			<tr id="Medications_<?php echo e($med->id); ?>">
				<td><span style="color:#FF0000;" id="Medications_remove_<?php echo e($med->id); ?>" class="removeTRecord"><img src="<?php echo e(asset('assets/Images/remove.png')); ?>"></span></td>
				<td><?php echo e($med->title); ?></td>
				<td><?php echo e($med->dosage); ?></td>
				<td><?php echo e($med->time_frame); ?></td>
			</tr>
			<?php endforeach; ?>
		<?php else: ?>
		<tr>
			<td></td>
			<td colspan="3">No record found</td>
		</tr>
		<?php endif; ?>
		</tbody>
	</table>
		
	<?php echo Form::open(array('novalidate'=>'novalidate','class'=>'test','method'=>'post', 'id' => 'medicalFrmClass')); ?>

	<?php echo Form::hidden('csrf-token',csrf_token()); ?>

	<div class="medicationHtml"></div>
	<div class="medicationSubmit"></div>
	<?php echo Form::close(); ?>

	
        <a class="addMedication" id="medicationID">Add a medication</a>
	</div>
	<div class="formFiled">	
	<h4>Allergies</h4>
	<table border="1" width="30%" cellpadding="10" cellspacing="10">
		<thead>
			<tr>
				<th></th>
				<th>Allergy</th>
			</tr>
		</thead>
		<tbody class="allergyAdd">
		<?php if($allergies->count() > 0): ?>
			<?php foreach($allergies as $allergy): ?>
			<tr id="allergies_<?php echo e($allergy->id); ?>">
				<td><span style="color:#FF0000;" id="allergies_remove_<?php echo e($allergy->id); ?>" class="removeTRecord"><img src="<?php echo e(asset('assets/Images/remove.png')); ?>"></span></td>
				<td><?php echo e($allergy->title); ?></td>
			</tr>
			<?php endforeach; ?>
		<?php else: ?>
		<tr>
			<td></td>
			<td colspan="3">No record found</td>
		</tr>
		<?php endif; ?>
		</tbody>
	</table>
	<?php echo Form::open(array('novalidate'=>'novalidate','class'=>'test','method'=>'post', 'id' => 'allergyFrmClass')); ?>

	<?php echo Form::hidden('csrf-token',csrf_token()); ?>

	<div class="allergyHtml"></div>
	<div class="allergySubmit"></div>
	<?php echo Form::close(); ?>	
        <a class="addMedication" id="allergyID">Add an Allergy</a>
		
	</div>
<div class="formFiled">		
	<h4>Medical Conditions</h4>
	<table border="1" width="30%" cellpadding="10" cellspacing="10">
		<thead>
			<tr>
				<th></th>
				<th>Medical Condition</th>
			</tr>
		</thead>
		<tbody class="medicalConditionAdd">
		<?php if($MedicalConditions->count() > 0): ?>
			<?php foreach($MedicalConditions as $mc): ?>
			<tr id="MedicalConditions_<?php echo e($mc->id); ?>">
				<td><span style="color:#FF0000;" id="MedicalConditions_remove_<?php echo e($mc->id); ?>" class="removeTRecord"><img src="<?php echo e(asset('assets/Images/remove.png')); ?>"></span></td>
				<td><?php echo e($mc->title); ?></td>
			</tr>
			<?php endforeach; ?>
		<?php else: ?>
		<tr>
			<td></td>
			<td colspan="3">No record found</td>
		</tr>
		<?php endif; ?>
		</tbody>
	</table>
	<?php echo Form::open(array('novalidate'=>'novalidate','class'=>'test','method'=>'post', 'id' => 'medicalConditionFrmClass')); ?>

	<?php echo Form::hidden('csrf-token',csrf_token()); ?>

	<div class="medicalConditionHtml"></div>
	<div class="medicalConditionSubmit"></div>
	<?php echo Form::close(); ?>	
        <a class="addMedication" id="medicalConditionID">Add a Medical Condition</a>
	</div>
	<div>I
	<?php if($details->easy_open_cap != ''): ?>
		<?php /**/ $easy_open_cap = $details->easy_open_cap /**/ ?>
	<?php else: ?>
		<?php /**/ $easy_open_cap = 'No' /**/ ?>
	<?php endif; ?>
	<?php echo Form::select('easy_open_cap',['Yes'=>'Yes','No'=>'No'],$easy_open_cap,array('id'=>'easy_open_cap')); ?>

	like easy-open caps on my prescription bottles.</div>
	<br>	
	<div>I would like my prescriptions to be filed with
	<?php if($details->prescription_filled != ''): ?>
		<?php /**/ $prescription_filled = $details->prescription_filled /**/ ?>
	<?php else: ?>
		<?php /**/ $prescription_filled = 'Generic' /**/ ?>
	<?php endif; ?>
	<?php echo Form::select('prescription_filled',['Generic'=>'Generic','Brand'=>'Brand'],$prescription_filled,array('id'=>'prescription_filled')); ?>

		whenever possibile.</div>
	<br>
		<div class="changeDrpDwn_msg" style="display:none">
			Your Patient Information has been successfully updated
		</div>
	<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>