<?php $__env->startSection('title', 'Forgot Password'); ?>
    
<?php $__env->startSection('content'); ?>
<?php if(Session::has('succ_msg')): ?>
        <div class="alert alert-success">
                <ul>
                        <li><?php echo Session::get('succ_msg'); ?></li>
                </ul>
        </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>