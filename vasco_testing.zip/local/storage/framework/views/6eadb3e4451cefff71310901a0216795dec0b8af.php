<p>
Dear <?php echo e($first_name .' '. $last_name); ?>,
</p>

<p>
You have requested to reset your Vasco RX Patient Portal password.  Please <a href="<?php echo e(URL::route('reset_password',$token)); ?>"> click here</a> to visit our website and create your new password. 
</p>

<p>
Thanks & Regards
<br>
Vasco Rx
</p>