<!DOCTYPE html>
<html>
<body>
    <p>Hello <?php echo e($fullname); ?>,</p>
    <p>Welcome to the Vasco RX Patient Portal, where you can manage the contact and billing information we have on file for you, as well as let us know of your current medications, allergies,
    and medical conditions, so that we can provide you the best possible service.</p>

    <p><a href="<?php echo e(URL::route('email_verification',$verification_code)); ?>">Click on this link</a> to verify your email address.</p>
    
    <p>
        Thanks & Regards
        <br>
        Vasco Rx
    </p>
</body>
</html>

