<?php $__env->startSection('title', 'Login'); ?>
    
<?php $__env->startSection('content'); ?>
    <div class="container">
    <h2>Login</h2>
		<?php if(count($errors) > 0): ?> 
                    <div class="alert alert-danger">
                    <ul>
                            <?php foreach($errors->all() as $error): ?>
                                    <li><?php echo e($error); ?></li>
                            <?php endforeach; ?>
                    </ul>
                    </div>
		<?php endif; ?>
		
		<?php if(Session::has('error_msg')): ?>
			<div class="alert alert-danger">
				<ul>
					<li><?php echo e(Session::get('error_msg')); ?></li>
				</ul>
			</div>
		<?php endif; ?>
            <?php echo Form::open(array('route'=>'user_login_action','id' => 'userLogin','novalidate'=>'novalidate')); ?>

            <div class="form-group">
              <label for="email">Email address:</label>
              <?php echo Form::email('email',null,array('placeholder'=>'Email address','class'=>'form-control')); ?>

            </div>
            <div class="form-group">
              <label for="pwd">Password:</label>
              <?php echo Form::password('password',array('placeholder'=>'Password','class'=>'form-control','id'=>'password')); ?>

            </div>
	    <div class="form-group">
	      <?php echo e(Html::link('forgot-password', 'Forgot Password?')); ?>

	      <?php echo e(Html::link('signup', 'Patient Registration')); ?>

            </div>
	    <div class="form-group">
	      <?php echo Form::submit('Login',array('class'=>'btn btn-default')); ?>

            </div>
            <?php echo Form::close(); ?>

	    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>