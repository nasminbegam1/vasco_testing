<?php $__env->startSection('title', 'Change Password'); ?>
    
<?php $__env->startSection('content'); ?>
    
	<div class="row">
		<div class="col-lg-12">
			<div class="col-lg-12 right-align">
	     
			<div class="logout2"><?php echo e(Html::link(route('logout'), 'Logout')); ?></div>
			 <div class="dash-btn" href="javascript:void(0)"><span>Change Password</span>		
			   <ul class="dropdown">
			     <li><?php echo e(Html::link('dashboard', 'Dashboard',array('class' => Helpers::isActiveRoute('dashboard')))); ?></li>
			     <li><?php echo e(Html::link(route('edit_profile'), 'Edit Profile and Billing',array('class' => Helpers::isActiveRoute('edit_profile')))); ?></li>
			     <li><?php echo e(Html::link(route('change_password'), 'Password Change',array('class' => Helpers::isActiveRoute('change_password')))); ?></li>		  
			   </ul>
			 </div>
			   
		       </div>
			
			
			<div class="col-lg-12">
				<h3 class="heading">Change Password</h3>
					<?php if(count($errors) > 0): ?> 
					    <div class="alert alert-danger">
					    <ul>
						    <?php foreach($errors->all() as $error): ?>
							    <li><?php echo e($error); ?></li>
						    <?php endforeach; ?>
					    </ul>
					    </div>
					<?php endif; ?>
					<?php if(Session::has('succ_msg')): ?>
						<div class="alert alert-success">
							<ul>
								<li><?php echo e(Session::get('succ_msg')); ?></li>
							</ul>
						</div>
					<?php endif; ?>
					<?php if(Session::has('error_msg')): ?>
						<div class="alert alert-danger">
							<ul>
								<li><?php echo e(Session::get('error_msg')); ?></li>
							</ul>
						</div>
					<?php endif; ?>
					
				    <?php echo Form::open(array('route'=>'password_change_action','id' => 'passwordChange','novalidate'=>'novalidate')); ?>

				      <div class="form-group">
					<label for="pwd">Old Password:</label>
					<?php echo Form::password('old_password',array('placeholder'=>'Old Password','class'=>'form-control required')); ?>

				      </div>
				      <div class="form-group">
					<label for="pwd">New Password:</label>
					<?php echo Form::password('new_password',array('placeholder'=>'New Password','class'=>'form-control','id'=>'new_password')); ?>

				      </div>
				      <div class="form-group">
					<label for="pwd">Re-enter New Password:</label>
					<?php echo Form::password('re_password',array('placeholder'=>'Re-enter New Password','class'=>'form-control')); ?>

				      </div>
				      <div class="form-group">
					 <?php echo Form::submit('Submit',array('class'=>'btn btn-default')); ?>

				      </div>
				    <?php echo Form::close(); ?>

			</div>
		</div>
	</div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>