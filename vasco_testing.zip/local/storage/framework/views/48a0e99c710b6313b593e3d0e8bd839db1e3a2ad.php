<!DOCTYPE html>
<html>
<body>
<?php echo $template_text; ?>

</body>
</html>

