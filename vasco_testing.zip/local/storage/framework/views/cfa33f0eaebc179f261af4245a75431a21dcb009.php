<?php $__env->startSection('title', 'Registration Success'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="subPages">
	<h2>Patient Registration</h2>
		
	
		
		
            <div class="clearfix patientinfo">
					<div class="signupSeccMsg">
						Thank you for your registration information.  Please check your email inbox for a link we sent you to verify your email address.
					</div>
		    </div>	
		    </div>	
		
	    
	    
	    
	    	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>