<?php $__env->startSection('title', 'Forgot Password'); ?>
    
<?php $__env->startSection('content'); ?>
	<h2>Reset Password</h2>
		<?php if(count($errors) > 0): ?> 
                    <div class="alert alert-danger">
                    <ul>
                            <?php foreach($errors->all() as $error): ?>
                                    <li><?php echo e($error); ?></li>
                            <?php endforeach; ?>
                    </ul>
                    </div>
		<?php endif; ?>
		
		<?php if(Session::has('error_msg')): ?>
			<div class="alert alert-danger">
				<ul>
					<li><?php echo Session::get('error_msg'); ?></li>
				</ul>
			</div>
		<?php endif; ?>
            <?php echo Form::open(array('route'=>'reset_password_action','id' => 'resetPassword','novalidate'=>'novalidate')); ?>

	    <?php echo Form::hidden('token',$token); ?>

            <div class="form-group">
              <label for="pwd">Password:</label>
              <?php echo Form::password('password',array('placeholder'=>'Password','class'=>'form-control required','id'=>'password')); ?>

            </div>
	    <div class="form-group">
              <label for="pwd">Re-enter Password:</label>
              <?php echo Form::password('re_password',array('placeholder'=>'Password','class'=>'form-control required')); ?>

            </div>
	    <div class="form-group">
	      <?php echo Form::submit('Submit',array('class'=>'btn submitBtn btn-default')); ?>

		  <?php echo e(Html::link('/', 'Login',array('class' => 'btn loginBtn btn-default'))); ?>

            </div>
            <?php echo Form::close(); ?>

	   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>