<?php $__env->startSection('title', 'Email Verification'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="subPages">
	<h2>Email Verification</h2>
		
		<div class="clearfix patientinfo">
				<?php if($verify_flag == 'success'): ?>
				<div class="emailVerifySuccMsg">
					
					Congratulations! Your email address has been verified, <a href="<?php echo e(URL::route('user_login')); ?>">Click here to login</a> to your dashboard.
				</div>
				<?php else: ?>
				<div class="emailVerifyErrMsg">
					Sorry! we are unable to verify your email id or may be your email id  has been verified already. 
				</div>	
				<?php endif; ?>
		</div>	
		</div>	
			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>