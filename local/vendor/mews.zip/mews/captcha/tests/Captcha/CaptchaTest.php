<?php

namespace Mews\Tests\Captcha;

use Mockery;

class CaptchaTest extends \PHPUnit_Framework_TestCase
{
    public function testConstructor()
    {
        $this->assertTrue(true);
    }
}
